import { Component, OnInit } from '@angular/core';
import { Portfolio } from '../../services/portfolio.model';
import { PortfolioService } from '../../services/portfolio.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  recentProjects: Portfolio[];
  constructor(private portfolioSvc: PortfolioService) { }

  ngOnInit() {
    this.portfolioSvc.get().subscribe(data => {
      this.recentProjects = data.splice(0, 7);
    });
  }

}
